$(document).ready(function() {
  $('body').append('<h1>Hello World</h1>');
});
$(document).ready(function() {
  // I don't do anything...
});


